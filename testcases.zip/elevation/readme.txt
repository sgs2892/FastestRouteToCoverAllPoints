Test: Elevation. The path should be routed around the black pixels.

Elevation: Mostly flat, black pixels are several orders of magnitude greater than the rest of the terrain.

Terrain: Most of it is easy, the black pixels represent the "mountains" and there are two yellow pixels that represent starting and ending spots
