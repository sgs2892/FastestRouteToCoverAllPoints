Test: Spring pixel flooding. The images should roughly match those in the example folder. Which pixels get flooded depends on if the diagonal pixels are treated as neighbors. Pay attention to the box of black pixels in the middle. You should not flood outside of the box, nor should any of the black pixels be flooded. 

Elevation: Mostly flat except for the black pixels which are several orders of magnitude higher.

Terrain: Most of it is easy, the black pixels represent the "mountains".
