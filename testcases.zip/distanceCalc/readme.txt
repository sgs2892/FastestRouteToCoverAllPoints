Test: Distance calc. There are two paths, 100px in along the x axis, 100 along the y. Their reported distances should be aprroximately (rounding errors) 1029 meters on the X path and 755 meters on the Y path.

Elevation: Flat
Terrain: All Easy
