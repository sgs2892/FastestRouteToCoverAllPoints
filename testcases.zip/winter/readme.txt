Test: Winter pixel freezing. The images should roughly match those in the example folder. Which pixels get frozen depends on if the diagonal pixels are treated as neighbors. 

Elevation: Flat

Terrain: Most of it is easy, there is a lake with a single land pixel in the middle 
